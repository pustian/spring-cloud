package com.miscx.turbine;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.cloud.netflix.turbine.EnableTurbine;
import org.springframework.context.ApplicationContext;

@SpringCloudApplication
@EnableDiscoveryClient
@EnableTurbine
@EnableHystrixDashboard
public class MiscTurbineApplication {

	private static Logger logger =  LoggerFactory.getLogger(MiscTurbineApplication.class);

	public static void main(String[] args) {
		ApplicationContext ctx = new SpringApplicationBuilder(MiscTurbineApplication.class).web(true).run(args);
    	String[] activeProfiles = ctx.getEnvironment().getActiveProfiles();  
    	for (String profile : activeProfiles) {
    		if (logger.isInfoEnabled()) {
    			logger.info("Spring-Boot's profile: {}" , profile);  
    		}
    	}
		if (logger.isInfoEnabled()) {
			logger.info("Misc-Turbine is done.");  
		}
	}

}
