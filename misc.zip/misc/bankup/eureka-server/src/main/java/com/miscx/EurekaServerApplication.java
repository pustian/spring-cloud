package com.miscx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.context.ApplicationContext;

@EnableEurekaServer
@SpringBootApplication
public class EurekaServerApplication {

	private static Logger logger =  LoggerFactory.getLogger(EurekaServerApplication.class);

	public static void main(String[] args) {
		ApplicationContext ctx = new SpringApplicationBuilder(EurekaServerApplication.class).web(true).run(args);
    	String[] activeProfiles = ctx.getEnvironment().getActiveProfiles();  
    	for (String profile : activeProfiles) {
    		if (logger.isInfoEnabled()) {
    			logger.info("Spring-Boot's profile: {}" , profile);  
    		}
    	}
		if (logger.isInfoEnabled()) {
			logger.info("Eureka-Server is done.");  
		}
	}

}
