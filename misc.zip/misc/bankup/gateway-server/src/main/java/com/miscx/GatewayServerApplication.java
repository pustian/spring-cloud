package com.miscx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.cloud.sleuth.sampler.AlwaysSampler;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.miscx.filter.AccessFilter;

@EnableZuulProxy
@SpringCloudApplication
public class GatewayServerApplication {
	
	private static Logger logger =  LoggerFactory.getLogger(GatewayServerApplication.class);

	public static void main(String[] args) {
		ApplicationContext ctx = new SpringApplicationBuilder(GatewayServerApplication.class).web(true).run(args);
    	String[] activeProfiles = ctx.getEnvironment().getActiveProfiles();  
    	for (String profile : activeProfiles) {
    		if (logger.isDebugEnabled()) {
    			logger.warn("Spring-Boot's profile: {}" , profile);  
    		}
    	}
		if (logger.isInfoEnabled()) {
			logger.info("Gateway-Server is done.");  
		}
	}

	@Bean
	public AccessFilter accessFilter() {
		return new AccessFilter();
	}
	
	@Bean
    public AlwaysSampler defaultSampler(){
        return new AlwaysSampler();
    }

}
