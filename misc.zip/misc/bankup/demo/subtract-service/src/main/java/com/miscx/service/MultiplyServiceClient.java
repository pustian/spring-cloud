package com.miscx.service;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient("multiply-service")
public interface MultiplyServiceClient {

    @RequestMapping(value = "/multiply",method = RequestMethod.GET)
    Integer multiply(@RequestParam(value = "a") Integer a, @RequestParam(value = "b") Integer b);

}
