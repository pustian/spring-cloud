package com.miscx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.sleuth.sampler.AlwaysSampler;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.miscx.service.DivideServiceClient;
import com.miscx.service.MultiplyServiceClient;

@SpringBootApplication
@RestController
@EnableFeignClients
@EnableDiscoveryClient
public class SubtractServiceApplication {

    private static final Logger logger = LoggerFactory.getLogger(SubtractServiceApplication.class.getName());

	public static void main(String[] args) {
		SpringApplication.run(SubtractServiceApplication.class, args);
	}

    @Autowired
    private MultiplyServiceClient multiplyServiceClient;

    @Autowired
    RestTemplate restTemplate;
    
    @Autowired
    private DiscoveryClient client;

    @RequestMapping(value = "/subtract" ,method = RequestMethod.GET)
    public Integer subtract(@RequestParam Integer a, @RequestParam Integer b) {
        ServiceInstance instance = client.getLocalServiceInstance();
        Integer r = a - b;
        logger.info("/subtract, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:" + r);
        return r;
    }
    
    @RequestMapping(value = "/multiply" ,method = RequestMethod.GET)
    public Integer multiply(@RequestParam Integer a, @RequestParam Integer b) {
        Integer r = multiplyServiceClient.multiply(a, b);
        ServiceInstance instance = client.getLocalServiceInstance();
        logger.info("/multiply, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:" + r);
        return r;
    }
    
    @RequestMapping(value = "/divide" ,method = RequestMethod.GET)
    public Integer divide(@RequestParam Integer a, @RequestParam Integer b) {
        String ret = restTemplate.getForEntity("http://DIVIDE-SERVICE/divide?a="+String.valueOf(a)+"&b="+String.valueOf(b), String.class).getBody();
        ServiceInstance instance = client.getLocalServiceInstance();
        logger.info("/divide, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:" + ret);
        return Integer.valueOf(ret);
    }

    @Bean
    public AlwaysSampler defaultSampler(){
        return new AlwaysSampler();
    }
    
	@Bean
	@LoadBalanced
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
