package com.miscx.service;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient("divide-service")
public interface DivideServiceClient {
    
    @RequestMapping(value = "/divide",method = RequestMethod.GET)
    Integer divide(@RequestParam(value = "a") Integer a, @RequestParam(value = "b") Integer b);

}
