package com.miscx.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CalcController {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private DiscoveryClient client;
    
    @Autowired
    RestTemplate restTemplate;

    @RequestMapping(value = "/add" ,method = RequestMethod.GET)
    public Integer add(@RequestParam Integer a, @RequestParam Integer b) {
        String ret = restTemplate.getForEntity("http://ADD-SERVICE/add?a="+String.valueOf(a)+"&b="+String.valueOf(b), String.class).getBody();
        ServiceInstance instance = client.getLocalServiceInstance();
        logger.info("/add, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:" + ret);
        return Integer.valueOf(ret);
    }
    
    @RequestMapping(value = "/subtract" ,method = RequestMethod.GET)
    public Integer subtract(@RequestParam Integer a, @RequestParam Integer b) {
        String ret = restTemplate.getForEntity("http://SUBTRACT-SERVICE/subtract?a="+String.valueOf(a)+"&b="+String.valueOf(b), String.class).getBody();
        ServiceInstance instance = client.getLocalServiceInstance();
        logger.info("/subtract, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:" + ret);
        return Integer.valueOf(ret);
    }
    
    @RequestMapping(value = "/multiply" ,method = RequestMethod.GET)
    public Integer multiply(@RequestParam Integer a, @RequestParam Integer b) {
        String ret = restTemplate.getForEntity("http://SUBTRACT-SERVICE/multiply?a="+String.valueOf(a)+"&b="+String.valueOf(b), String.class).getBody();
        ServiceInstance instance = client.getLocalServiceInstance();
        logger.info("/multiply, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:" + ret);
        return Integer.valueOf(ret);
    }
    
    @RequestMapping(value = "/divide" ,method = RequestMethod.GET)
    public Integer divide(@RequestParam Integer a, @RequestParam Integer b) {
        String ret = restTemplate.getForEntity("http://SUBTRACT-SERVICE/divide?a="+String.valueOf(a)+"&b="+String.valueOf(b), String.class).getBody();
        ServiceInstance instance = client.getLocalServiceInstance();
        logger.info("/divide, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:" + ret);
        return Integer.valueOf(ret);
    }
    
    @RequestMapping(value = "/calc" ,method = RequestMethod.GET)
    public String calc(@RequestParam Integer a, @RequestParam Integer b) {
    	Integer add = this.add(a, b);
    	Integer subtract = this.subtract(a, b);
    	Integer multiply = this.multiply(a, b);
    	Integer divide = this.divide(a, b);
        ServiceInstance instance = client.getLocalServiceInstance();
        logger.info("/calc, host:" + instance.getHost() + ", service_id:" + instance.getServiceId() + ", result:"+add+subtract+multiply+divide);
        return "done";
    }

}