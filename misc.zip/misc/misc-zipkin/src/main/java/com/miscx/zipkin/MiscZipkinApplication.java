package com.miscx.zipkin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import zipkin.server.EnableZipkinServer;

@SpringBootApplication
@EnableZipkinServer
@EnableDiscoveryClient
public class MiscZipkinApplication {
	private final static Logger logger = LoggerFactory.getLogger(MiscZipkinApplication.class);
	
	public static void main(String[] args) {
		ApplicationContext ctx = new SpringApplicationBuilder(MiscZipkinApplication.class).web(true).run(args);
    	String[] activeProfiles = ctx.getEnvironment().getActiveProfiles();  
    	for (String profile : activeProfiles) {
    		if (logger.isInfoEnabled()) {
    			logger.info("Spring-Boot's profile: {}" , profile);  
    		}
    	}
		if (logger.isInfoEnabled()) {
			logger.info("Misc-Zipkin is done.");  
		}
	}
}
