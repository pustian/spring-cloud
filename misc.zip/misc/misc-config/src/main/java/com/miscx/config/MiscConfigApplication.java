package com.miscx.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.context.ApplicationContext;

@EnableConfigServer
@SpringBootApplication
public class MiscConfigApplication {
	
	private static Logger logger =  LoggerFactory.getLogger(MiscConfigApplication.class);

	public static void main(String[] args) {
		ApplicationContext ctx = new SpringApplicationBuilder(MiscConfigApplication.class).web(true).run(args);
    	String[] activeProfiles = ctx.getEnvironment().getActiveProfiles();  
    	for (String profile : activeProfiles) {
    		if (logger.isInfoEnabled()) {
    			logger.info("Spring-Boot's profile: {}" , profile);  
    		}
    	}
		if (logger.isInfoEnabled()) {
			logger.info("Misc-Config is done.");  
		}
	}

}
