配置中心。

配置采用非对称加密，生成keystore命令如下：
keytool -genkeypair -alias mykey -keyalg RSA -dname "CN=Web Server,OU=Unit,O=Organization,L=City,S=State,C=US" -keypass changeme -keystore conf.jks -storepass letmein
加密命令如下：
curl http://confuser:Qaz!3%2$1wsX@localhost:7001/encrypt -d 123456
解密命令如下：
curl http://confuser:Qaz!3%2$1wsX@localhost:7001/decrypt -d AQBQzLmLlo3w9LJX1DiIw8coHaIGtgxuO+Z2TXB/9j+R9Dp/m+4A62pgIWXe58DghJPU2tMkixPgAyra+UkYnBiKDfpX7cy0Tc2021qx14ovvqhK0aDHT01nJ4XOj8WNwX2wUduxDgtrrRStSydhWxPSBRxFC1ord/iw2CBGmkt+Te9V8b6Aho3IYJ6/Gf5o0Lh6wThSAQxGjOqtMakJ+e/oVwGuNmPtKRkQEC67M3IHYtaZQ3z8GYpZ0VuKzYu6KsVy2FK3ocnw8M8E0cWnYqKtVzL0WbTXDGcHv6Ma/mafh0aogKhi7k+trNE3I/uS4gpkCcXLH+TuHbAxOdQnKUcFV/Oc/Y5Q7MHcwpfWYxED2ZJvIlswu0V/KF+tLKIWIco=