package com.miscx.eureka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.context.ApplicationContext;

@EnableEurekaServer
@SpringBootApplication
public class MiscEurekaApplication {

	private static Logger logger =  LoggerFactory.getLogger(MiscEurekaApplication.class);

	public static void main(String[] args) {
		ApplicationContext ctx = new SpringApplicationBuilder(MiscEurekaApplication.class).web(true).run(args);
    	String[] activeProfiles = ctx.getEnvironment().getActiveProfiles();  
    	for (String profile : activeProfiles) {
    		if (logger.isInfoEnabled()) {
    			logger.info("Spring-Boot's profile: {}" , profile);  
    		}
    	}
		if (logger.isInfoEnabled()) {
			logger.info("Misc-Eureka is done.");  
		}
	}

}
